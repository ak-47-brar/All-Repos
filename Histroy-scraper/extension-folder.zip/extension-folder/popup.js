document.addEventListener('DOMContentLoaded', function() {
  const saveHistoryButton = document.getElementById('saveHistory');
  
  if (saveHistoryButton) {
    saveHistoryButton.addEventListener('click', () => {
      // Use Chrome's history API to retrieve all browsing history
      chrome.history.search({ text: '', maxResults: 999999 }, function(historyItems) {
        // Prepare a string to hold the formatted history
        let historyText = '';
        
        // Iterate through the history items and format them
        for (const item of historyItems) {
          const date = new Date(item.lastVisitTime);
          const formattedDate = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
          const formattedEntry = `${formattedDate} - ${item.url} - ${item.title}\n\n`; // Include double line break
          historyText += formattedEntry;
        }
    
        // Create a Blob containing the history data
        const blob = new Blob([historyText], { type: 'text/plain' });
    
        // Create a URL for the Blob
        const url = URL.createObjectURL(blob);
    
        // Create a download link and trigger a download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'complete_history.txt';
        document.body.appendChild(a);
        a.click();
    
        // Clean up
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      });
    });
  } else {
    console.error("Element with ID 'saveHistory' not found.");
  }
});

// content.js

console.log("Content script injected!");
